import pandas as pd
import numpy as np
la=pd.read_csv("AQI_Data.csv")
print("first 5 rows are : ",la.head(5))  #for printing first 5 rows
print("Last 6 rows are : ",la.tail(5))  #for printing last 6 rows
print(la.describe())
print("the mean of AQI:")
t=[la.loc[:,'AQI']]

print(np.mean(t))

print("the mean of pm2.5:")

o=[la.loc[:,'PM2.5']]

print(np.mean(o))

print("the mean of pm10")

f=[la.loc[:,'PM10']]

print(np.mean(f))


unhealthy= la[la['PM2.5'] > 100] # for finding unhealthy cities
print("Rows where PM2.5 level exceeds 100 (unhealthy):")
print(unhealthy) #for printing unhealthy cities

city_counts = {} #for counting the number of cities
for city in la['City'].unique():
    city_df = la[la['City'] == city]
    unhealthy_count = len(city_df[city_df['PM2.5'] > 100])
    city_counts[city] = unhealthy_count

print("\nCount of unhealthy PM2.5 levels for each city:")
for city, count in city_counts.items():
    print(f"{city}: {count}")





    


